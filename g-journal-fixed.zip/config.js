// Supabase Configuration
// Замініть ці значення на ваші власні з вашого Supabase проекту

window.CONFIG = {
    // Отримайте ці значення з: Project Settings → API
    SUPABASE_URL: "https://ixnjbdvabaanyvnakwue.supabase.co",
    SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml4bmpiZHZhYmFhbnl2bmFrd3VlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgxMjU2NjksImV4cCI6MjA4MzcwMTY2OX0.XVbat9-rhmkGW7D_8t9d-cqpz95orsqzgbakWUXvQGE"
};

// Інструкції:
// 1. Створіть проект на https://supabase.com
// 2. Виконайте SQL скрипт з файлу supabase-setup.sql
// 3. Перейдіть у Project Settings → API
// 4. Скопіюйте "Project URL" та "anon public" ключ
// 5. Замініть значення вище

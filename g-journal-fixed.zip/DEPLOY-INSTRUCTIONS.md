# 🚀 Інструкція по деплою G Trade Journal

## Файли в архіві

- `index.html` - головна сторінка
- `styles.css` - стилі
- `app.js` - логіка додатку
- `config.js` - конфігурація Supabase (вже налаштована)
- `logo.png` - логотип
- `README.md` - документація
- `supabase-setup-fixed.sql` - SQL скрипт для бази даних (вже виконано)

## Варіант 1: Netlify (РЕКОМЕНДОВАНО)

### Крок 1: Створити акаунт
1. Йдіть на [netlify.com](https://netlify.com)
2. Зареєструйтесь (можна через GitHub)

### Крок 2: Deploy сайту
1. На головній сторінці Netlify натисніть **"Add new site"** → **"Deploy manually"**
2. Перетягніть всі файли з архіву (або всю папку) в зону drag & drop
3. Зачекайте 30 секунд - сайт буде онлайн!
4. Netlify дасть вам URL типу `https://random-name-123.netlify.app`

### Крок 3: Підключити свій домен (опціонально)
1. Купіть домен на [namecheap.com](https://namecheap.com) або [porkbun.com](https://porkbun.com)
   - Рекомендую `.xyz` або `.site` - коштує $1-3/рік
2. В Netlify: перейдіть у **Domain settings** → **Add custom domain**
3. Введіть ваш домен (наприклад, `gjournal.xyz`)
4. Netlify покаже DNS записи, які треба додати
5. В Namecheap/Porkbun: перейдіть у **Domain Management** → **Advanced DNS**
6. Додайте DNS записи:
   - `A Record` → `@` → IP з Netlify
   - `CNAME` → `www` → ваш-сайт.netlify.app
7. Зачекайте 5-30 хвилин для оновлення DNS
8. SSL сертифікат налаштується автоматично

## Варіант 2: GitHub Pages

### Крок 1: Створити репозиторій
1. Йдіть на [github.com](https://github.com) та зареєструйтесь
2. Натисніть **"New repository"**
3. Назвіть репозиторій `g-trade-journal`
4. Зробіть його **Public**
5. Натисніть **"Create repository"**

### Крок 2: Завантажити файли
1. На сторінці репозиторію натисніть **"uploading an existing file"**
2. Перетягніть всі файли з архіву
3. Натисніть **"Commit changes"**

### Крок 3: Увімкнути GitHub Pages
1. Перейдіть у **Settings** → **Pages**
2. В **Source** виберіть `main` branch
3. Натисніть **Save**
4. Через 2-3 хвилини ваш сайт буде доступний на `https://username.github.io/g-trade-journal`

### Крок 4: Підключити свій домен (опціонально)
1. В **Settings** → **Pages** → **Custom domain** введіть ваш домен
2. В налаштуваннях домену додайте DNS записи:
   - `A Record` → `@` → `185.199.108.153`
   - `A Record` → `@` → `185.199.109.153`
   - `A Record` → `@` → `185.199.110.153`
   - `A Record` → `@` → `185.199.111.153`
   - `CNAME` → `www` → `username.github.io`

## Варіант 3: Vercel

1. Йдіть на [vercel.com](https://vercel.com)
2. Зареєструйтесь через GitHub
3. Натисніть **"Add New"** → **"Project"**
4. Імпортуйте репозиторій з GitHub або завантажте файли вручну
5. Натисніть **"Deploy"**
6. Готово! Сайт буде доступний на `https://your-project.vercel.app`

## Перевірка після деплою

1. Відкрийте сайт у браузері
2. Спробуйте зареєструватись (email + пароль мінімум 6 символів)
3. Додайте тестовий трейд
4. Перевірте Equity Curve
5. Спробуйте функцію Share (публічне посилання)

## Важливо

- База даних Supabase вже налаштована та працює
- Всі credentials (URL, API ключ) вже в `config.js`
- SSL (HTTPS) налаштується автоматично на всіх платформах
- Не треба нічого змінювати в коді - все готово до деплою

## Проблеми?

Якщо щось не працює:
1. Перевірте консоль браузера (F12 → Console)
2. Переконайтесь що всі файли завантажились
3. Перевірте що сайт доступний по HTTPS (не HTTP)

## Додаткова допомога

- Netlify Docs: https://docs.netlify.com
- GitHub Pages Docs: https://docs.github.com/pages
- Vercel Docs: https://vercel.com/docs

---

Успішного деплою! 🚀
